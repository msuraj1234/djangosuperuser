from django.apps import AppConfig


class ImageappConfig(AppConfig):
    name = 'imageapp'
