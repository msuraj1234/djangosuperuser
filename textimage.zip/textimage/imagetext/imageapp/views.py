from django.shortcuts import render, HttpResponse
from .forms import Profile_Form
from .models import User_Profile

# Create your views here.
# IMAGE_FILE_TYPES = ['png', 'jpg', 'jpeg']

def create_profile(request):
    form = Profile_Form()
    if request.method == 'POST':
        form = Profile_Form(request.POST, request.FILES)
        if form.is_valid():
            user_pr = form.save(commit=False)
            user_pr.display_picture = request.FILES['display_picture']
            # file_type = user_pr.display_picture.url.split('.')[-1]
            # file_type = file_type.lower()
            # if file_type not in IMAGE_FILE_TYPES:
            #     return render(request, 'profile_maker/error.html')
            user_pr.save()
            return render(request, 'profile_maker/details.html', {'user_pr': user_pr})
    context = {"form": form,}
    return render(request, 'profile_maker/create.html', context)

# def index(request):
#     products= Product.objects.all()
#     allProds=[]
#     catprods= Product.objects.values('category', 'id')
#     cats= {item["category"] for item in catprods}
#     for cat in cats:
#         prod=Product.objects.filter(category=cat)
#         n = len(prod)
#         nSlides = n // 4 + ceil((n / 4) - (n // 4))
#         allProds.append([prod, range(1, nSlides), nSlides])

#     params={'allProds':allProds }
#     return render(request,"shop/index.html", params)
