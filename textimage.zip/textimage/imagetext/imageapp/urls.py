from django.contrib import admin
from django.urls import path
from imageapp import views
from imageproject import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.create_profile, name = 'imageapp')
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root = settings.STATICFILES_DIRS)
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)